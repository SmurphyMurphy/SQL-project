USE sql_project;

SELECT *
FROM students;

SELECT *
FROM students
WHERE students_professors_courses = 1;

SELECT *
FROM students
WHERE students_professors_courses = 2;

SELECT AVG(grades_id)
FROM students;

UPDATE students
SET students_grades_id = 95
WHERE students_id = 1